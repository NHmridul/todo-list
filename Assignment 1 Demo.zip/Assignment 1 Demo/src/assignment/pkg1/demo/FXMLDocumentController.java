/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg1.demo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;

/**
 *
 * @author kmhasan
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private ListView<String> dateListView;
    @FXML
    private ListView<String> eventListView;
    @FXML
    private DatePicker datePicker;
    @FXML
    private TextField eventName;
    @FXML
    private TextField titleField;
    @FXML
    private ListView<CheckBox> todoListView;
    @FXML
    private ListView<CheckBox> completedListView;

    ArrayList<Todo> todoList = new ArrayList();
    ObservableList<String> dateList = FXCollections.observableArrayList();
    ObservableList<String> eventList = FXCollections.observableArrayList();
    ObservableList<CheckBox> toDoList = FXCollections.observableArrayList();
    ObservableList<CheckBox> completedList = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        try {
            datePicker.setValue(LocalDate.now());
            dateListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
            addTodoList();
            addDateLists();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    void updateFile() throws IOException {
        File file = new File("todolist.txt");
        if (!file.exists()) {
            file.createNewFile();
        }

        PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(file)));
        for (Todo t : todoList) {
            writer.println(t.getDate());
            writer.println(t.getTitle());
            for (String tList : t.todoItemList) {
                writer.println(tList);
            }
            writer.println("#");
            for (String cList : t.completedItemList) {
                writer.println(cList);
            }
            writer.println("##");
        }
        writer.close();
    }

    void addTodoList() throws IOException {
        File file = new File("todolist.txt");
        if (!file.exists()) {
            file.createNewFile();
        }

        Scanner sc = new Scanner(file);
        while (sc.hasNext()) {
            Todo t = new Todo();
            String d = sc.nextLine();
            t.setDate(LocalDate.parse(d));

            String eName;
            if (sc.hasNext()) {
                eName = sc.nextLine();
                if (!eName.equals("#") && !eName.equals("##")) {
                    t.setTitle(eName);
                }
            }

            String todoName;
            if (sc.hasNext()) {
                todoName = sc.nextLine();
                if (!todoName.equals("#")) {
                    do {
                        t.todoItemList.add(todoName);
                        if (sc.hasNext()) {
                            todoName = sc.nextLine();
                        }

                    } while (!todoName.equals("#"));
                }
            }
            String comName;
            if (sc.hasNext()) {
                comName = sc.nextLine();
                if (!comName.equals("##")) {
                    do {
                        t.completedItemList.add(comName);
                        if (sc.hasNext()) {
                            comName = sc.nextLine();
                        }
                    } while (!comName.equals("##"));
                }
            }
            todoList.add(t);

        }
        sc.close();
        
    }

    void addDateLists() {
        for (Todo t : todoList) {
            
            dateList.add(t.getDate().toString());
        }

        dateListView.setItems(dateList);
        
    }

    @FXML
    private void addEvent(ActionEvent event) throws IOException {

        String eName = eventName.getText();

        LocalDate d = datePicker.getValue();
        System.out.println(d);

        if (eName.equals("") && d.equals(null)) {
            return;
        }
        Todo t = new Todo(d, eName);
        todoList.add(t);

        updateFile();
        dateList.clear();
        addDateLists();

        eventName.clear();
        datePicker.setValue(LocalDate.now());
    }
    
    @FXML
    private void datelistMouseClicked(MouseEvent event) {
        eventList.clear();
        String d = dateListView.getSelectionModel().getSelectedItem();

        for (Todo t : todoList) {
            if (t.getDate().toString().equals(d)) {
                eventList.add(t.getTitle());
            }
        }
        eventListView.setItems(eventList);
    }

    void checkBoxAction(CheckBox c, Todo t) throws IOException {
        if (c.isSelected()) {
            toDoList.remove(c);
            completedList.add(c);

            todoListView.setItems(toDoList);
            completedListView.setItems(completedList);
            t.todoItemList.remove(c.getText());
            t.completedItemList.add(c.getText());
        } else if (!c.isSelected()) {
            toDoList.add(c);
            completedList.remove(c);

            todoListView.setItems(toDoList);
            completedListView.setItems(completedList);
            t.todoItemList.add(c.getText());
            t.completedItemList.remove(c.getText());
        }
        updateFile();
    }

    String EVENT_NAME = "";
    
    @FXML
    private void eventListViewMouseClicked(MouseEvent event) throws IOException {
        toDoList.clear();
        completedList.clear();
        String eName = eventListView.getSelectionModel().getSelectedItem();
        EVENT_NAME = eName;

        for (Todo t : todoList) {
            if (t.getTitle().equals(eName)) {
                for (String tName : t.todoItemList) {
                    CheckBox c = new CheckBox(tName);
                    c.setOnAction(click -> {
                        try {
                            checkBoxAction(c, t);
                        } catch (IOException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });

                    toDoList.add(c);
                }
                for (String cName : t.completedItemList) {
                    CheckBox c = new CheckBox(cName);
                    c.setSelected(true);
                    c.setOnAction(click -> {
                        try {
                            checkBoxAction(c, t);
                        } catch (IOException ex) {
                            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });
                    completedList.add(c);

                }
                break;
            }
            
        }
        todoListView.setItems(toDoList);
        completedListView.setItems(completedList);

        
        //addDateLists();

    }

    @FXML
    private void addTodoListHandle(ActionEvent event) throws IOException {
        if (EVENT_NAME.equals("")) {
            return;
        }

        String todoName = titleField.getText();
        CheckBox c = new CheckBox(todoName);
        

        for (Todo t : todoList) {
            if (t.getTitle().equals(EVENT_NAME)) {
                
                c.setOnAction(click -> {
                    try {
                        checkBoxAction(c, t);
                    } catch (IOException ex) {
                        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                });
                t.todoItemList.add(todoName);
                break;
            }
        }
        toDoList.add(c);
        updateFile();
        titleField.clear();
    }

    @FXML
    private void resetButtonAction(ActionEvent event) throws IOException {
        File file=new File("todolist.txt");
        if(!file.exists()) file.createNewFile();
        
        PrintWriter writer=new PrintWriter(new BufferedWriter(new FileWriter(file)));
        writer.println("");
        writer.close();
        
        todoList.clear();
        toDoList.clear();
        dateList.clear();
        eventList.clear();
        completedList.clear();
        
    }

}
